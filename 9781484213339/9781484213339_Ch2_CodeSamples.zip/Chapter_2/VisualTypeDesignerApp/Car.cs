﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VisualTypeDesignerApp
{
    public class Car
    {
        public string petName;
    }
}