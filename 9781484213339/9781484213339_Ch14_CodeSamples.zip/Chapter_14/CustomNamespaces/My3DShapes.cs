﻿// Another shape-centric namespace.
using System;
namespace My3DShapes
{
    // 3D Circle class.
    public class Circle { }

    // 3D Hexagon class.
    public class Hexagon { }

    // 3D Square class.
    public class Square { }
}
