﻿using System.ComponentModel.DataAnnotations;

namespace AutoLotDAL.Models.MetaData
{
    public class InventoryMetaData
    {
        [Display(Name="Pet Name")]
        public string PetName;
    }
}
